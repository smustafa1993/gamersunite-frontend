import { voteComment, reportComment } from '../services/commentService.js'
import { useState } from 'react'

export default function CommentList({ user, items, onVoted, onReported }) {
  // Track which masked comments the user chose to reveal (by _id)
  const [revealed, setRevealed] = useState(new Set())
  const revealOne = (id) => {
    setRevealed(prev => {
      const copy = new Set(prev)
      copy.add(id)
      return copy
    })
  }

  return (
    <div className="col" style={{ gap: 12 }}>
      {items.map(c => (
        <div key={c._id} className="card">
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
            <div style={{color:'var(--muted)', fontSize:13}}>
              {c.author?.displayName || 'Unknown'} · {new Date(c.createdAt).toLocaleString()}
            </div>
            <div className="row">
              <button className="btn secondary" onClick={async ()=>{
                const u = await voteComment(c._id, 1)
                onVoted?.(u)
              }}>▲</button>
              <span style={{minWidth:32, textAlign:'center'}}>{c.votes}</span>
              <button className="btn secondary" onClick={async ()=>{
                const u = await voteComment(c._id, -1)
                onVoted?.(u)
              }}>▼</button>
              <button className="btn secondary" onClick={async ()=>{
                const u = await reportComment(c._id)
                onReported?.(u)
              }}>Report</button>
            </div>
          </div>

          <div style={{marginTop:8}}>
            {c.masked && !revealed.has(c._id) ? (
              <div className="spoiler">
                Spoiler hidden. Preview: {c.preview}{' '}
                <button className="btn secondary" onClick={() => revealOne(c._id)}>
                  Reveal
                </button>
              </div>
            ) : (
              <div style={{whiteSpace:'pre-wrap'}}>
                {c.body || c.preview}
              </div>
            )}
          </div>
        </div>
      ))}
      {items.length === 0 && <div className="card">No comments yet.</div>}
      {!user && <div className="card" style={{color:'var(--muted)'}}>Login to vote or post.</div>}
    </div>
  )
}
