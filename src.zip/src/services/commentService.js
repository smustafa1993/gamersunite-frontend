import api from './api'

export async function listComments(levelId, sort='new', reveal=false) {
  const {data} = await api.get(`/comments/level/${levelId}`, {
    params: { sort, reveal: reveal ? 1 : 0 }
  })
  return data
}
export async function addComment(levelId,body){ const {data}=await api.post(`/comments/level/${levelId}`,{body}); return data }
export async function voteComment(id,value){ const {data}=await api.post(`/comments/${id}/vote`,{value}); return data }
export async function reportComment(id){ const {data}=await api.post(`/comments/${id}/report`); return data }
