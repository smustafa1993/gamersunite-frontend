import api from './api'
export async function setProgress(gameId, levelNumber){ const {data}=await api.put(`/progress/${gameId}`,{levelNumber}); return data }
