import { useEffect, useState } from 'react'
import { setProgress } from '../services/progressService.js'
import { listGames } from '../services/gameService.js'

export default function ProfilePage({ user }) {
  const [games, setGames] = useState([])
  const [selected, setSelected] = useState('')
  const [levelNumber, setLevelNumber] = useState('0')
  const [msg, setMsg] = useState('')

  useEffect(() => { listGames().then(setGames) }, [])

  async function save(e) {
    e.preventDefault()
    setMsg('')
    if (!selected) return
    await setProgress(selected, Number(levelNumber))
    setMsg('Progress saved.')
  }

  return (
    <div className="card" style={{maxWidth:560}}>
      <h2>Profile</h2>
      <div style={{color:'var(--muted)'}}>Logged in as {user?.displayName} — {user?.email}</div>

      <form onSubmit={save} className="col" style={{marginTop:16}}>
        <strong>Set Progress</strong>
        <select className="input" value={selected} onChange={e=>setSelected(e.target.value)}>
          <option value="">Select a game…</option>
          {games.map(g => <option key={g._id} value={g._id}>{g.title}</option>)}
        </select>
        <input className="input" type="number" min="0" placeholder="Highest level number reached"
          value={levelNumber} onChange={e=>setLevelNumber(e.target.value)} />
        <button className="btn">Save</button>
        {msg && <div style={{color:'#22c55e'}}>{msg}</div>}
      </form>
    </div>
  )
}
