import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { getLevel } from '../services/levelService.js'
import { listComments } from '../services/commentService.js'
import CommentList from '../components/CommentList.jsx'
import CommentForm from '../components/CommentForm.jsx'

export default function LevelDetailPage({ user }) {
  const { levelId } = useParams()
  const [level, setLevel] = useState(null)
  const [comments, setComments] = useState([])
  const [showSpoilers, setShowSpoilers] = useState(false)


useEffect(() => { load() }, [levelId, showSpoilers])
async function load() {
  const l = await getLevel(levelId); setLevel(l)
  const c = await listComments(levelId, 'new', showSpoilers) // pass flag
  setComments(c.comments)
}


  if (!level) return <div className="card">Loading…</div>

  return (
    <div className="col" style={{ gap:16 }}>
      <div className="card">
        <div className="row" style={{justifyContent:'space-between'}}>
          <div>
            <div style={{color:'var(--muted)'}}><Link className="link" to={`/games/${level.game.slug}`}>{level.game.title}</Link></div>
            <h2 style={{margin:'8px 0'}}>Level #{level.number}: {level.title}</h2>
          </div>
          <div style={{color:'var(--muted)'}}>Your progress on this game may hide spoilers.</div>
          <div className="row" style={{alignItems:'center', gap:8}}>
  <input
    id="spoilers"
    type="checkbox"
    checked={showSpoilers}
    onChange={e => setShowSpoilers(e.target.checked)}
  />
  <label htmlFor="spoilers" className="link">Show spoilers</label>
</div>
        </div>
        {level.summary && <p style={{whiteSpace:'pre-wrap', marginTop:8}}>{level.summary}</p>}
      </div>

      {user && <CommentForm levelId={levelId} onPosted={load} />}
      <CommentList user={user} items={comments} onVoted={load} onReported={load} />
    </div>
  )
}

